import React from "react";

function NoteHeader() {
  return (
    <div className="notes_header">
      <h1>Notes</h1>
    </div>
  );
}

export default NoteHeader;
