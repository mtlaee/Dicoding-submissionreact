import React from "react";

function MessageEmpty() {
  return <p className="empty-message">Tidak Ada Catatan</p>;
}

export default MessageEmpty;
